# SQL injection detector

This package proporcionates the capability of detecting sql injection in your json/dict data.
Regardles of how your data looks like and how nested is your dictionary, it will go through 
each step and provide a response